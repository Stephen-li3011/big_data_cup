# Stathletes Public Data User Agreement
Stathletes is making this data set publicly available to promote new research in the space and a deeper understanding of the game of hockey. The events have been translated from Stathletes’ raw data to enhance accessibility and interpretability. Any research that is produced from this dataset is free to be shared publicly, provided that said research is not used for profit. Stathletes retains the right to publish any work submitted for the Hackathon.
<br>
<br>
Github access to Stathletes Data (the ‘Service’) is provided by Stathletes (‘Stathletes’) to any user (the ‘User’) who agrees to use the data according to the Terms and Conditions of this Agreement.
<br>
<br>
This Agreement governs the use of the Service. By using the Service the User will be bound by all terms making up this Agreement.
